let Appoinment = [] ;
function placeapp(){

    var appoint={
      
      FirstName:document.getElementById("fname").value+""+document.getElementById("lname").value,
    Address:document.getElementById("addr").value+""+document.getElementById("state").value,
    City:document.getElementById("city").value,
    Phone:document.getElementsByClassName("mob").value,
    Package:document.getElementById("package").value,
    TrainerPref:document.getElementById("trainerpref").value
   
    };
    if(Appoinment.FirstName !=="" && appoint.Address !==""&& appoint.City!==""&& appoint.Phone!==""&& appoint.Package!==""&& appoint.TrainerPref!==""){
        Appoinment=JSON.parse(localStorage.getItem("appoint"));
        Appoinment.push(appoint);
        localStorage.setItem("appoint",JSON.stringify( Appoinment));
        window.open("viewAppoinment.html");
       
    }

}
